"""
test image ignore
=====================
"""
#%%
#
# .. image:: https://user-images.githubusercontent.com/16088743/185366359-c6ecff54-95f2-4016-b762-649a7b4a9a1e.png
#     :alt: line survey output


#%%
#
# .. image:: https://user-images.githubusercontent.com/16088743/185366359-c6ecff54-95f2-4016-b762-649a7b4a9a1e.png
#     :alt: line survey output


#%%
#
## .. |pic1| image:: ../../_static/_images/sphx_glr_plot_test.png
#     :width: 45%
#


#%%
#
## .. image:: ../../_static/_images/sphx_glr_plot_test.png
#
